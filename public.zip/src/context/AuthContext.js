"use client";
import React, { createContext, useContext, useEffect, useState, useCallback, useRef } from 'react';
import { authAPI, notificationAPI } from '@/lib/api';
import { toast } from 'react-toastify';

const AuthContext = createContext({
  user: null,
  loading: true,
  login: async () => {},
  logout: async () => {},
  isAuthenticated: false,
  refreshUser: async () => {},
  getUserInitials: () => 'U',
  getDisplayName: () => 'User',
  formatLastLogin: () => null,
});

// ⏰ Session configuration
const SESSION_CONFIG = {
  DURATION: 4 * 60 * 60 * 1000, // 8 hours in milliseconds
  WARNING_TIME: 5 * 60 * 1000, // Show warning 5 minutes before expiry
  CHECK_INTERVAL: 60 * 1000, // Check every minute
};

// Token management
const tokenManager = {
  get: () => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('auth_token');
    }
    return null;
  },
  
  set: (token) => {
    if (typeof window !== 'undefined') {
      localStorage.setItem('auth_token', token);
    }
  },
  
  remove: () => {
    if (typeof window !== 'undefined') {
      localStorage.removeItem('auth_token');
      localStorage.removeItem('auth_user');
      localStorage.removeItem('session_start');
      localStorage.removeItem('fcm_token');
    }
  }
};

// User data management
const userManager = {
  get: () => {
    if (typeof window !== 'undefined') {
      const user = localStorage.getItem('auth_user');
      return user ? JSON.parse(user) : null;
    }
    return null;
  },
  
  set: (user) => {
    if (typeof window !== 'undefined') {
      localStorage.setItem('auth_user', JSON.stringify(user));
    }
  },
  
  remove: () => {
    if (typeof window !== 'undefined') {
      localStorage.removeItem('auth_token');
      localStorage.removeItem('auth_user');
      localStorage.removeItem('session_start');
      localStorage.removeItem('fcm_token');
    }
  }
};

// Session management
const sessionManager = {
  start: () => {
    if (typeof window !== 'undefined') {
      const now = Date.now();
      localStorage.setItem('session_start', now.toString());
      sessionStorage.setItem('session_active', 'true');
    }
  },
  
  getStartTime: () => {
    if (typeof window !== 'undefined') {
      const startTime = localStorage.getItem('session_start');
      return startTime ? parseInt(startTime) : null;
    }
    return null;
  },
  
  isExpired: () => {
    const startTime = sessionManager.getStartTime();
    if (!startTime) return true;
    
    const elapsed = Date.now() - startTime;
    return elapsed >= SESSION_CONFIG.DURATION;
  },
  
  getTimeRemaining: () => {
    const startTime = sessionManager.getStartTime();
    if (!startTime) return 0;
    
    const elapsed = Date.now() - startTime;
    const remaining = SESSION_CONFIG.DURATION - elapsed;
    return Math.max(0, remaining);
  },
  
  shouldShowWarning: () => {
    const remaining = sessionManager.getTimeRemaining();
    return remaining > 0 && remaining <= SESSION_CONFIG.WARNING_TIME;
  },
  
  clear: () => {
    if (typeof window !== 'undefined') {
      localStorage.removeItem('session_start');
      sessionStorage.removeItem('session_active');
    }
  },
  
  isNewSession: () => {
    if (typeof window !== 'undefined') {
      return !sessionStorage.getItem('session_active');
    }
    return false;
  }
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showSessionWarning, setShowSessionWarning] = useState(false);
  const sessionCheckIntervalRef = useRef(null);
  const warningToastIdRef = useRef(null);

  // 🔔 Delete FCM token before logout
  const deleteFCMToken = async () => {
    try {
      const fcmToken = localStorage.getItem('fcm_token');
      if (fcmToken) {
        await notificationAPI.deleteFCMToken(fcmToken);
        localStorage.removeItem('fcm_token');
        console.log('✅ FCM token deleted');
      }
    } catch (error) {
      console.error('❌ Failed to delete FCM token:', error);
    }
  };

  // ⏰ Check session validity
  const checkSession = useCallback(async () => {
    if (!tokenManager.get()) return;

    if (sessionManager.isExpired()) {
      console.log('⏰ Session expired - auto logout');
      
      // Delete FCM token
      await deleteFCMToken();
      
      // Clear toast if exists
      if (warningToastIdRef.current) {
        toast.dismiss(warningToastIdRef.current);
      }
      
      // Show expiry message
      toast.error('Sesi Anda telah berakhir. Silakan login kembali.', {
        autoClose: 5000,
      });
      
      // Logout
      tokenManager.remove();
      userManager.remove();
      sessionManager.clear();
      setUser(null);
      setShowSessionWarning(false);
      
      // Redirect to login
      if (typeof window !== 'undefined') {
        window.location.replace('/');
      }
    } else if (sessionManager.shouldShowWarning() && !showSessionWarning) {
      setShowSessionWarning(true);
      const remaining = Math.ceil(sessionManager.getTimeRemaining() / 60000);
      
      // Dismiss previous warning if exists
      if (warningToastIdRef.current) {
        toast.dismiss(warningToastIdRef.current);
      }
      
      // Show new warning
      warningToastIdRef.current = toast.warning(
        `Sesi Anda akan berakhir dalam ${remaining} menit. Simpan pekerjaan Anda.`,
        {
          autoClose: false,
          closeButton: true,
        }
      );
    }
  }, [showSessionWarning]);

  // Start session monitoring
  useEffect(() => {
    if (user && tokenManager.get()) {
      // Check immediately
      checkSession();
      
      // Then check periodically
      sessionCheckIntervalRef.current = setInterval(
        checkSession,
        SESSION_CONFIG.CHECK_INTERVAL
      );
      
      return () => {
        if (sessionCheckIntervalRef.current) {
          clearInterval(sessionCheckIntervalRef.current);
        }
      };
    }
  }, [user, checkSession]);

  // Initialize auth state
  useEffect(() => {
    const initializeAuth = async () => {
      console.log('🔄 Initializing auth...');
      setLoading(true);
      
      const token = tokenManager.get();
      const savedUser = userManager.get();
      
      // 🔑 Check if this is a new session (browser/tab was closed)
      const isNewSession = sessionManager.isNewSession();
      
      if (isNewSession) {
        console.log('🆕 New session detected - clearing page state');
        // Clear current page to reset to dashboard
        localStorage.removeItem('currentPage');
      }
      
      console.log('📦 Token:', token ? 'exists' : 'none');
      console.log('👤 Saved user:', savedUser ? savedUser.username : 'none');
      console.log('🆕 Is new session:', isNewSession);
      
      if (token && savedUser) {
        // Check if session is expired
        if (sessionManager.isExpired()) {
          console.log('⏰ Session expired on init');
          await deleteFCMToken();
          tokenManager.remove();
          userManager.remove();
          sessionManager.clear();
          setUser(null);
          setLoading(false);
          return;
        }
        
        try {
          // Verify token with server
          const response = await authAPI.me();
          console.log('✅ Token verified:', response.data?.username);
          setUser(response.data);
          userManager.set(response.data);
          
          // Mark session as active
          sessionManager.start();
        } catch (error) {
          console.error('❌ Token verification failed:', error);
          await deleteFCMToken();
          tokenManager.remove();
          userManager.remove();
          sessionManager.clear();
          setUser(null);
        }
      } else {
        console.log('❌ No token or user found');
        setUser(null);
      }
      
      setLoading(false);
      console.log('✅ Auth initialization complete');
    };

    initializeAuth();
  }, []);

  // Login function
  const login = useCallback(async (credentials) => {
    console.log('🔐 Login attempt:', credentials.username);
    setLoading(true);
    try {
      const response = await authAPI.login(credentials);
      console.log('✅ Login response:', response);
      
      if (response.success && response.data) {
        const { token, user: userData } = response.data;
        
        tokenManager.set(token);
        userManager.set(userData);
        sessionManager.start();
        setUser(userData);
        
        console.log('✅ User logged in:', userData.username);
        
        // Clear current page to start fresh
        localStorage.removeItem('currentPage');
        
        // Redirect using replace to prevent back navigation
        if (typeof window !== 'undefined') {
          window.location.replace('/');
        }
        
        return response;
      }
      
      throw new Error(response.message || 'Login failed');
    } catch (error) {
      console.error('❌ Login error:', error);
      setUser(null);
      throw error;
    } finally {
      setLoading(false);
    }
  }, []);

  // Logout function
  const logout = useCallback(async () => {
    console.log('🚪 Logout...');
    setLoading(true);
    
    // Dismiss any active warnings
    if (warningToastIdRef.current) {
      toast.dismiss(warningToastIdRef.current);
    }
    
    try {
      // Delete FCM token first
      await deleteFCMToken();
      
      // Then logout from server
      await authAPI.logout();
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      // Clear all data
      tokenManager.remove();
      userManager.remove();
      sessionManager.clear();
      setUser(null);
      setShowSessionWarning(false);
      setLoading(false);
      
      // Clear session interval
      if (sessionCheckIntervalRef.current) {
        clearInterval(sessionCheckIntervalRef.current);
      }
      
      console.log('✅ Logged out');
      
      // Redirect using replace
      if (typeof window !== 'undefined') {
        window.location.replace('/');
      }
    }
  }, []);

  // Refresh user data
  const refreshUser = useCallback(async () => {
    if (tokenManager.get()) {
      try {
        const response = await authAPI.me();
        if (response.success && response.data) {
          setUser(response.data);
          userManager.set(response.data);
          return response.data;
        }
      } catch (error) {
        console.error('User refresh failed:', error);
        await logout();
        throw error;
      }
    }
  }, [logout]);

  // Helper functions
  const getUserInitials = useCallback(() => {
    if (!user?.username) return 'U';
    return user.username.substring(0, 2).toUpperCase();
  }, [user]);

  const getDisplayName = useCallback(() => {
    return user?.username || 'User';
  }, [user]);

  const formatLastLogin = useCallback(() => {
    if (!user?.last_login_at) return null;
    
    const date = new Date(user.last_login_at);
    return date.toLocaleString('id-ID', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  }, [user]);

  const value = {
    user,
    loading,
    login,
    logout,
    refreshUser,
    isAuthenticated: !!user && !!tokenManager.get() && !sessionManager.isExpired(),
    getUserInitials,
    getDisplayName,
    formatLastLogin,
    sessionExpiring: showSessionWarning,
    timeRemaining: sessionManager.getTimeRemaining(),
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

// Custom hook to use auth context
export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
};

export default AuthContext;